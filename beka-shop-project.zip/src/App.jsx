import React, { useRef, useState } from "react";

export default function App() {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(50);

  const toggleMusic = () => {
    if (!audioRef.current) return;

    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
      audioRef.current.volume = volume / 100;
    }

    setPlaying(!playing);
  };

  const products = [
    {
      name: "Nike Air Max",
      price: "$220",
      img: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Adidas Runner",
      price: "$190",
      img: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Puma Gold",
      price: "$240",
      img: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  return (
    <div style={{background:"#000",color:"#fff",minHeight:"100vh",fontFamily:"Arial"}}>
      <audio ref={audioRef} loop src="/music.mp3"></audio>

      <header style={{padding:"20px",borderBottom:"1px solid #333",display:"flex",justifyContent:"space-between"}}>
        <h1 style={{color:"gold"}}>Beka Shop</h1>
        <button onClick={toggleMusic} style={{padding:"10px 20px",background:"gold",border:"none",borderRadius:"10px"}}>
          {playing ? "Pause Music" : "Play Music"}
        </button>
      </header>

      <section style={{padding:"80px 20px",textAlign:"center"}}>
        <h2 style={{fontSize:"50px"}}>Beka Shop — стильная обувь нового поколения</h2>
        <p style={{color:"#aaa",fontSize:"20px"}}>
          Качество, комфорт и современный стиль в одном месте
        </p>
      </section>

      <section style={{display:"grid",gridTemplateColumns":"repeat(auto-fit,minmax(250px,1fr))",gap:"20px",padding:"40px"}}>
        {products.map((p, i) => (
          <div key={i} style={{background:"#111",borderRadius:"20px",overflow:"hidden"}}>
            <img src={p.img} alt={p.name} style={{width:"100%",height:"300px",objectFit:"cover"}} />
            <div style={{padding:"20px"}}>
              <h3>{p.name}</h3>
              <p style={{color:"gold"}}>{p.price}</p>
              <button style={{padding:"10px 20px",background:"gold",border:"none",borderRadius:"10px"}}>
                Купить
              </button>
            </div>
          </div>
        ))}
      </section>

      <div style={{
        position:"fixed",
        right:"20px",
        bottom:"20px",
        background:"#111",
        border:"1px solid gold",
        borderRadius:"20px",
        padding:"20px",
        width:"300px"
      }}>
        <h3 style={{color:"gold"}}>Beka AI</h3>
        <p>Привет 👋 Я помогу подобрать обувь.</p>
        <input placeholder="Напишите сообщение..." style={{
          width:"100%",
          padding:"12px",
          borderRadius:"10px",
          border:"1px solid #333",
          background:"#000",
          color:"#fff"
        }} />
      </div>
    </div>
  );
}
