# Beka Shop

## Запуск проекта

1. Установить Node.js
2. Открыть терминал
3. Выполнить:

npm install
npm run dev

## Или загрузить в Vercel / CodeSandbox
